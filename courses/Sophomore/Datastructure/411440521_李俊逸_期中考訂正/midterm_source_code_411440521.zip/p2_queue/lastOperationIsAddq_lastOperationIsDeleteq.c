/*
(a)
int emptyq(CircularQueue *q) {
    return (q->front == -2);
}

int fullq(CircularQueue *q) {
    return ((q->rear + 2) % SIZE == q->front);
}
(b)
int emptyq(CircularQueue *q) {
    return (q->front == -2);
}

int fullq(CircularQueue *q) {
    return ((q->rear + 2) % SIZE == q->front);
}
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define SIZE 100

typedef struct {
    int data[SIZE];
    int front;
    int rear;
    int lastOperationIsDeleteq; // 0 for delete, 1 for addq
} CircularQueue;

void init_circular_queue(CircularQueue *q) {
    q->front = -1;
    q->rear = -1;
    q->lastOperationIsDeleteq = 0;
}

// 411440521 JoshLee
// Circular Queue functions
int emptyq(CircularQueue *q) {
    return (q->front == -1);
}

int fullq(CircularQueue *q) {
    return ((q->rear + 1) % SIZE == q->front);
}

void addq(CircularQueue *q, int val) {
    if(!fullq(q)) {
        if(emptyq(q)) {
            q->front = 0;
        }
        q->rear = (q->rear + 1) % SIZE;
        q->data[q->rear] = val;
        q->lastOperationIsDeleteq = 1;
    }
}
// 411440521 JoshLee
int deleteq(CircularQueue *q) {
    int val = -1;
    if(!emptyq(q)) {
        val = q->data[q->front];
        if(q->front == q->rear) {
            q->front = -1;
            q->rear = -1;
        } else {
            q->front = (q->front + 1) % SIZE;
        }
        q->lastOperationIsDeleteq = 0;
    }
    return val;
}

int sizeq(CircularQueue *q) {
    return q->rear - q->front + 1;
}


// Questions
void random_number_generator(CircularQueue* q, int range, int offset, int len) {
    srand(time(NULL));          // use srand(time(NULL)) to set seed of random number generator as current time
    int i;
    for(i = 0; i < len; i++)
        addq(q, rand() % range + offset);  // generate random number
}
// 411440521 JoshLee
void restore(CircularQueue *ele_q, CircularQueue *deleted_ele_q) {
    while(!emptyq(ele_q)) {           // deleted_ele_q = deleted_ele_q + ele_q
        addq(deleted_ele_q, deleteq(ele_q));
    }
    while(!emptyq(deleted_ele_q)) {         // ele_q = deleted_ele_q
        addq(ele_q, deleteq(deleted_ele_q));
    }
}

void print_queue(CircularQueue* ele_q, int ElementsInOneLine) {
    CircularQueue temp_q;
    init_circular_queue(&temp_q);
    int ElementsInCurrentLine = 0;

    while(!emptyq(ele_q)) {
        int deleted_value = deleteq(ele_q); addq(&temp_q, deleted_value);
        printf("%d ", deleted_value);
        if(++ElementsInCurrentLine >= ElementsInOneLine) {
            printf("\n");
            ElementsInCurrentLine = 0;
        }
    }
    restore(ele_q, &temp_q);
    printf("\n");
}
// 411440521 JoshLee
void reverseQueue(CircularQueue *q) {
    // base case
    if (emptyq(q))
        return;
    // store front(first element) of queue, and remove front
    int fr = deleteq(q);
 
    // asking recursion to reverse the leftover queue
    reverseQueue(q);
 
    // placing first element at its correct position
    addq(q, fr);
}
// 411440521 JoshLee
int getElement(CircularQueue *ele_q, int fromFront, int n) {    // 1 is fromFront, 0 is fromBack
    CircularQueue temp_q;
    init_circular_queue(&temp_q);
    int i, deleted_value;
    
    if(fromFront == 1) {
        for(i = 0; i < n; i++) {
            deleted_value = deleteq(ele_q);
            addq(&temp_q, deleted_value);
        }
        restore(ele_q, &temp_q);
    } else {
        reverseQueue(ele_q);
        for(i = 0; i < n; i++) {
            deleted_value = deleteq(ele_q);
            addq(&temp_q, deleted_value);
        }
        // restore ele_q
        restore(ele_q, &temp_q);
        reverseQueue(ele_q);
    }
    return deleted_value;
}

// 411440521 JoshLee
int main() {
    CircularQueue q;
    init_circular_queue(&q);

    // p1
    random_number_generator(&q, 100, 1, 18);  // Use rand()%100+1 to get 21 random numbers
    print_queue(&q, 9);     // 9 numbers in one line

    // p2
    int n = getElement(&q, 1, 10);
    printf("n = %d \n\n", n);
    
    // p3
    print_queue(&q, 9);     // 9 numbers in one line

    return 0;
}
