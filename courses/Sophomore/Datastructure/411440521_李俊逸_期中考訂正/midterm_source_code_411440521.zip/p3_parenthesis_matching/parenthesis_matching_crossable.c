#include <stdio.h>
#include <stdlib.h>

#define SIZE 100
int stack[SIZE]; // store (left_brackets_pos) * 10 + encoded_left_bracket
int top = -1;

// stack functions
int full();
int empty();
void push(int);
int pop();

// self defined
char corresponding_bracket(char);
int encode_left_bracket(char);
char decode_left_bracket(int);
// 411440521 JoshLee
int main() {
    char symb;
    int pos = 0;

    while ((symb = getchar()) != '\n') {
        if (symb == '(' || symb == '[' || symb == '{') {
            int left_bracket_type = encode_left_bracket(symb);
            push(pos * 10 + left_bracket_type); // * NOTICE * tens and higher stands for left_bracket_position; ones stands for left_bracket_type
        } else if (symb == ')' || symb == ']' || symb == '}') {
            char right_bracket = symb; // right_bracket on pos
            if (!empty()) {
                int popped_value = pop(); // encoded_left_bracket on the top of the stack
                int left_bracket_pos = popped_value / 10; // get pos
                char left_bracket = decode_left_bracket(popped_value % 10); // get bracket type
                if ((right_bracket == ')' && left_bracket == '(') ||
                    (right_bracket == ']' && left_bracket == '[') ||
                    (right_bracket == '}' && left_bracket == '{')) { // if paired
                    printf("%c%d,%d%c\n", left_bracket, left_bracket_pos, pos, right_bracket); // print bracket pair position
                } else { // if not paired
                    push(popped_value);
                    // ��m�s��%d�����A��%c�S���i�t�諸�k�A��%c"
                    // printf("left parenthesis %c at %d has no matching right parenthesis %c\n", left_bracket, pos, corresponding_bracket(left_bracket));
                    printf("right parenthesis %c at %d has no matching left parenthesis %c\n", right_bracket, pos, corresponding_bracket(right_bracket));
                }
            } else { // lack left_bracket
                printf("right parenthesis %c at %d has no matching left parenthesis %c\n", right_bracket, pos, corresponding_bracket(right_bracket));
            }
        }
        pos++;
    }
    while (!empty()) { // �Ѿl���|�̪����A�����S���k�A��
        int popped_value = pop();
        int left_bracket_pos = popped_value / 10;
        char left_bracket = decode_left_bracket(popped_value % 10);
        printf("left parenthesis %c at %d has no matching right parenthesis %c\n", left_bracket, left_bracket_pos, corresponding_bracket(left_bracket));
    }
    return 0;
}
// 411440521 JoshLee
int full() {
    return top == SIZE - 1;
}

int empty() {
    return top == -1;
}

void push(int c) {
    if (!full()) {
        stack[++top] = c;
    } else {
        printf("Stack is full!\n");
        exit(1); // exit with failure code 1
    }
}

int pop() {
    if (!empty()) {
        int popped_value = stack[top];
        stack[top--] = 0;
        return popped_value;
    } else {
        printf("Stack is empty!\n");
        exit(2); // exit with failure code 2
    }
}
// 411440521 JoshLee
char corresponding_bracket(char bracket) {
    if (bracket == '(') return ')';
    if (bracket == '[') return ']';
    if (bracket == '{') return '}';
    if (bracket == ')') return '(';
    if (bracket == ']') return '[';
    if (bracket == '}') return '{';
    return '\0';
}

int encode_left_bracket(char bracket) {
    if (bracket == '(') return 1;
    if (bracket == '[') return 2;
    if (bracket == '{') return 3;
    return -1;
}

char decode_left_bracket(int encoded_bracket) {
    if (encoded_bracket == 1) return '(';
    if (encoded_bracket == 2) return '[';
    if (encoded_bracket == 3) return '{';
    return '\0';
}

