#include <stdio.h>
#include <stdlib.h>
#include <time.h>  // use time() to get current time

#define SIZE 100

typedef struct {
    int data[SIZE];
    int top;
} Stack;

void init_stack(Stack *s) {
    s->top = -1;
}

// Stack functions
int full(Stack *s) {
    return s->top == SIZE - 1;
}

int empty(Stack *s) {
    return s->top == -1;
}

void push(Stack *s, int val) {
    if(!full(s))
        s->data[++(s->top)] = val;
    else {
        printf("Stack is full!");
        exit(1);
    }
}
// 411440521 JoshLee
int pop(Stack *s) {
    if(!empty(s))
        return s->data[(s->top)--];
    printf("Stack is empty!");
    exit(2);
}

// Questions
void random_number_generator(Stack* s, int range, int offset, int len) {
    srand(time(NULL));          // use srand(time(NULL)) to set seed of random number generator as current time
    int i;
    for(i = 0; i < len; i++)
        push(s, rand() % range + offset);  // generate random number
}

void print_stack(Stack* ele_s, int ElementsInOneLine) {
    Stack temp_popped;
    init_stack(&temp_popped);
    int ElementsInCurrentLine = 0;
    
    while(!empty(ele_s)) {
        int popped_value = pop(ele_s);
        printf("%d ", popped_value);  // remove '\n' if output is too long
        push(&temp_popped, popped_value);
        if(++ElementsInCurrentLine >= ElementsInOneLine) {
            printf("\n");
            ElementsInCurrentLine = 0;
        }
    }
    while(!empty(&temp_popped)) {
        int popped_value = pop(&temp_popped);
        push(ele_s, popped_value);
    }
    printf("\n");
}
// 411440521 JoshLee
void restore(Stack *ele_s, Stack *temp_s) {
    while(!empty(temp_s)) {
        push(ele_s, pop(temp_s));
    }
}

void reverseStack(Stack *s) {
    Stack s1;
    Stack s2;
    init_stack(&s1);
    init_stack(&s2);
    while(!empty(s)) {
        push(&s1, pop(s));
    }
    while(!empty(&s1)) {
        push(&s2, pop(&s1));
    }
    while(!empty(&s2)) {
        push(s, pop(&s2));
    }
}

int getElement(Stack *s, int fromTop, int n) {    // 1 is fromTop, 0 is fromBottom
    Stack temp_popped;
    init_stack(&temp_popped);
    int i, popped_value;
    
    if(fromTop == 1) {
        for(i = 0; i < n; i++) {
            popped_value = pop(s);
            push(&temp_popped, popped_value);
        }
        restore(s, &temp_popped);
    } else {
        reverseStack(s);    // reverse s to pop the bottom n-th element
        for(i = 0; i < n; i++) {
            popped_value = pop(s);
            push(&temp_popped, popped_value);
        }
        restore(s, &temp_popped);  // restore s
        reverseStack(s);    // reverse s to restore to origion
    }
    return popped_value;
}

// 411440521 JoshLee
int main() {
    Stack s;
    init_stack(&s);

    // p1
    random_number_generator(&s, 100, 1, 18);  // Use rand()%100+1 to get 18 random numbers
    print_stack(&s, 9);    // 9 numbers in one line

    // p2 element out of size
    int i = getElement(&s, 0, 1);  // fromBottom 1st element
    printf("i = %d \n\n", i);

    // p3
	int j = getElement(&s, 0, 2);  // fromBottom 2nd element
    printf("j = %d \n\n", j);

    // p4
    int k = getElement(&s, 0, 3);  // fromBottom 3rd element
    printf("k = %d \n\n", k);

    // p5
    print_stack(&s, 9);    // 9 numbers in one line

    // p6
    int m = getElement(&s, 0, 4);
    printf("m = %d \n\n", m);
    
    return 0;
}
